"""Module for Flutterwave payment gateway"""

# Having this for the future purpose
