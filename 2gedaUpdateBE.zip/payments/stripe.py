"""Module for Stripe payment gateway"""

# Having this for the future purpose
