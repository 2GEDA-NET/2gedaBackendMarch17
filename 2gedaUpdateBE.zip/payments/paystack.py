from decimal import Decimal
from typing import Any

import requests
from django.conf import settings


class Paystack(object):
    """Paystack class for API"""

    base_url: str = settings.PAYSTACK_BASE_URL
    kobo: int = 100
    network_error: dict[str, Any] = {
        "message": "Can not complete the transaction. Try again.",
        "status": False,
    }
    headers: dict[str, str] = {
        "Authorization": f"Bearer {settings.PAYSTACK_SECRET_KEY}",
        "context_type": "application/json",
    }

    @classmethod
    def initialize(
        cls, amount: int | float | Decimal, email: str, **params
    ) -> tuple[bool, dict]:
        url = f"{cls.base_url}/transaction/initialize"
        amount_str = f"{amount * cls.kobo}"
        # callback_url =
        data = {"amount": amount_str, "email": email}  # , "callback_url": callback_url}
        data.update(params)

        try:
            response = requests.post(url=url, data=data, headers=cls.headers)
        except requests.exceptions.ConnectionError:
            return False, cls.network_error
        else:
            return True, response.json()

    @classmethod
    def verify(cls, reference: str) -> tuple[bool, dict]:
        url = f"{cls.base_url}/transaction/verify/{reference}"
        try:
            response = requests.get(url=url, headers=cls.headers)
        except requests.exceptions.ConnectionError:
            return False, cls.network_error
        else:
            return True, response.json()
